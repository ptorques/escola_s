/**
 * 
 */
/**
 * @author pedro_torques
 *
 */
module oopjava {
}