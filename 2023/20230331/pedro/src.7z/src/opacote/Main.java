package opacote;

public class Main {
	public static void main (String[] args) {
		Animal vini = new Animal("Vini", 4.7)
		Cachorro matheus = new Cachorro("Matheus", "Daschund", 3.5);
		
		vini.imprimir();
		matheus.imprimir();
	}
}
